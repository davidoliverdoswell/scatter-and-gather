//
//  MovieController.swift
//  MyMovies
//
//  Created by Spencer Curtis on 8/17/18.
//  Copyright © 2018 Lambda School. All rights reserved.
//

import Foundation
import CoreData

class MovieController {
    
    private let apiKey = "4cc920dab8b729a619647ccc4d191d5e"
    private let baseURL = URL(string: "https://api.themoviedb.org/3/search/movie")!
    
    private let firebaseURL = URL(string: "https://movie-793d7.firebaseio.com/")!
    
    let moc = CoreDataStack.shared.mainContext
    
    typealias CompletionHandler = (Error?) -> Void
    
    init() {
        let backgroundContext = CoreDataStack.shared.container.newBackgroundContext()
        fetchMoviesFromServer(context: backgroundContext)
    }
    
    // search logic
    
    func searchForMovie(with searchTerm: String, completion: @escaping (Error?) -> Void) {
        
        var components = URLComponents(url: baseURL, resolvingAgainstBaseURL: true)
        
        let queryParameters = ["query": searchTerm,
                               "api_key": apiKey]
        
        components?.queryItems = queryParameters.map({URLQueryItem(name: $0.key, value: $0.value)})
        
        guard let requestURL = components?.url else {
            completion(NSError())
            return
        }
        
        URLSession.shared.dataTask(with: requestURL) { (data, _, error) in
            
            if let error = error {
                NSLog("Error searching for movie with search term \(searchTerm): \(error)")
                completion(error)
                return
            }
            
            guard let data = data else {
                NSLog("No data returned from data task")
                completion(NSError())
                return
            }
            
            do {
                let movieRepresentations = try JSONDecoder().decode(MovieRepresentations.self, from: data).results
                self.searchedMovies = movieRepresentations
                completion(nil)
            } catch {
                NSLog("Error decoding JSON data: \(error)")
                completion(error)
            }
        }.resume()
    }
    
    // fetch, update, and put logic on background thread
    
    func fetchMoviesFromServer(completion: @escaping CompletionHandler = {_ in}, context: NSManagedObjectContext) {
        
        let requestURL = baseURL.appendingPathExtension("json")
        
        URLSession.shared.dataTask(with: requestURL) { (data, _, error) in
            if let error = error {
                NSLog("Error: \(error)")
            }
            
            guard let data = data else {
                NSLog("No data")
                completion(NSError())
                return
            }
            
            context.performAndWait {
                do {
                    let movieRepresentations = Array(try JSONDecoder().decode([String: MovieRepresentation].self, from: data).values)
                    
                    let backgroundMoc = CoreDataStack.shared.container.newBackgroundContext()
                    
                    // save the context only after the update/creation process is complete
                    
                    try self.updateMovies(with: movieRepresentations, context: backgroundMoc)
                    
                    // remember that save() itself must be called on the context's private queue using perform() or performAndWait()
                    
                    try CoreDataStack.shared.save()
                    completion(nil)
                    
                } catch {
                    NSLog("Error: \(error)")
                    completion(error)
                    return
                }
            }
        }.resume()
    }
    
    func updateMovies(with representations: [MovieRepresentation], context: NSManagedObjectContext) throws {
        
        var error : Error?
        
        context.performAndWait {
            
            for movieRep in representations {
                guard let uuid = UUID(uuidString: (movieRep.identifier?.uuidString)!) else { continue }
                
                let movie = self.fetchMovie(forUUID: uuid, context: context)
                
                if let movie = movie {
                    self.update(movie: movie, with: movieRep, title: movie.title!)
                } else {
                    let _ = Movie(title: (movie?.title)!, identifier: (movie?.identifier)!, hasWatched: (movie?.hasWatched)!, context: context)
                }
            }
            
            do {
                try context.save()
            } catch let saveError {
                error = saveError
            }
        }
        if let error = error { throw error }
    }
    
    
    func put(movie: Movie, with representations: [MovieRepresentation], completion: @escaping CompletionHandler = {_ in}) {
        
        let uuid = movie.identifier ?? UUID()
        
        let requestURL = baseURL.appendingPathComponent(uuid.uuidString).appendingPathExtension("json")
        
        var request = URLRequest(url: requestURL)
        request.httpMethod = "PUT"
        
        do {
            guard var representation = movie.movie else {
                completion(NSError())
                return
            }
            representation.identifier = uuid.uuidString
            movie.identifier = uuid
            try CoreDataStack.shared.save()
            request.httpBody = try JSONEncoder().encode(representation)
        } catch {
            NSLog("Error: \(error)")
            completion(error)
            return
        }
        
        URLSession.shared.dataTask(with: request) { (data, _, error) in
            if let error = error {
                NSLog("Error: \(error)")
                completion(error)
                return
            }
            completion(nil)
        }.resume()
    }
    
    // crud ops
    
    func create(movie: Movie, title: String, identifier: UUID, hasWatched: Bool = false) {
        
        movie.title = title
        movie.identifier = identifier
        movie.hasWatched = hasWatched
        
        put(movie: movie)
    }
    
    func update(movie: Movie, with representation: MovieRepresentation, title: String, hasWatched: Bool = false) {
        
        movie.title = representation.title
        movie.hasWatched = representation.hasWatched!
        
        put(movie: movie)
    }
    
    func delete(movie: Movie) {
        moc.delete(movie)
        deleteEntryFromServer(movie: movie)
    }
    
    func deleteEntryFromServer(movie: Movie, completion: @escaping CompletionHandler = {_ in}) {
        
        guard let identifier = movie.identifier else { return }
        
        let url = baseURL.appendingPathComponent(identifier.uuidString)
            .appendingPathExtension("json")
        
        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"
        
        URLSession.shared.dataTask(with: request) { (data, _, error) in
            if let error = error {
                NSLog("Error: \(error)")
                completion(error)
                return
            }
            completion(nil)
            }.resume()
    }
    
   // fetch a single movie
    
    private func fetchMovie(forUUID uuid: UUID, context: NSManagedObjectContext) -> Movie? {
        let fetchRequest: NSFetchRequest<Movie> = Movie.fetchRequest()
        
        fetchRequest.predicate = NSPredicate(format: "identifier == %@", uuid as NSUUID)
        
        do {
            return try context.fetch(fetchRequest).first
        } catch {
            NSLog("Error: \(error)")
            return nil
        }
    }
    
    
    // MARK: - Properties
    
    var searchedMovies: [MovieRepresentation] = []
}
