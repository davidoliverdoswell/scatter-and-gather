//
//  MovieTableViewCell.swift
//  MyMovies
//
//  Created by Lambda-School-Loaner-11 on 8/17/18.
//  Copyright © 2018 Lambda School. All rights reserved.
//

import UIKit
import CoreData

class MovieTableViewCell: UITableViewCell {
    
    var movie: Movie? {
        didSet {
            updateViews()
        }
    }
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBAction func addMovieButton(_ sender: Any) {
        
        //TODO
        
        do {
            let moc = CoreDataStack.shared.mainContext
            try moc.save()
        } catch {
            NSLog("Error saving managed object context: \(error)")
        }
    }
    
    private func updateViews() {
        
        titleLabel.text = movie?.title
    }
    
    

}
